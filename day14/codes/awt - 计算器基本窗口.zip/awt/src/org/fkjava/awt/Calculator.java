package org.fkjava.awt;

import java.awt.Dimension;
import java.awt.Frame;
import java.awt.Toolkit;

public class Calculator {

	public static void main(String[] args) {
		// 创建一个窗口
		Frame win = new Frame("超级无敌简单计算器");

		// 设置窗口的大小
		int width = 300;
		int height = 300;
		win.setSize(width, height);

		// 在居中窗口
		// 获取Toolkit，利用Toolkit可以获得屏幕的宽度和高度
		Toolkit toolkit = win.getToolkit();
		Dimension size = toolkit.getScreenSize();
		int screenWidth = size.width;
		int screenHeight = size.height;
		int x = screenWidth / 2 - width / 2;
		int y = screenHeight / 2 - height / 2;
		win.setLocation(x, y);

		// 把所有组件都添加完成以后，需要显示窗口
		// 如果在运行中修改了组件，也需要再次调用显示窗口的方法
		win.setVisible(true);
	}
}
