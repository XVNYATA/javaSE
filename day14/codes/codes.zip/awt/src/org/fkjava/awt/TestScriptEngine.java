package org.fkjava.awt;

import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;

public class TestScriptEngine {

	public static void main(String[] args) throws ScriptException {

		// 创建一个脚本引擎管理器
		ScriptEngineManager sem = new ScriptEngineManager();

		// 获得一个JavaScript脚本的执行环境
		ScriptEngine se = sem.getEngineByName("JavaScript");

		String script = " 345*34+345-21/2 ";

		// 利用脚本引擎，直接执行算术表达式，得到计算结果
		Object result = se.eval(script);

		// 得到的result正是计算结果
		System.out.println(result);
	}
}
