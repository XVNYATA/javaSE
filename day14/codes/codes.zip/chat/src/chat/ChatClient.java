package chat;

/**
 * 聊天的客户端，入口。所有聊天的动作，比如发送信息、接收信息，都是在这个客户端里面操作。显示专门交给界面进行显示。
 * 
 * @author lwq
 *
 */
public class ChatClient {

	public static void main(String[] args) {
		// 创建一个群聊的界面
		ChatFrame chatFrame = new ChatFrame();
		
		chatFrame.setVisible(true);
	}
}
