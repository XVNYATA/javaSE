package chat;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Toolkit;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTextArea;

/**
 * 群聊界面
 * 
 * @author lwq
 *
 */
public class ChatFrame extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ChatFrame() {
		// 设置标题
		super("疯狂群聊");
		// ==========================================================
		// 设置窗口的大小
		int width = 800;
		int height = 600;
		super.setSize(width, height);
		// ==========================================================
		// 居中窗口
		// 获取Toolkit，利用Toolkit可以获得屏幕的宽度和高度
		Toolkit toolkit = super.getToolkit();
		Dimension size = toolkit.getScreenSize();
		int screenWidth = size.width;
		int screenHeight = size.height;
		int x = screenWidth / 2 - width / 2;
		int y = screenHeight / 2 - height / 2;
		super.setLocation(x, y);
		// ==========================================================
		// 处理关闭窗口事件
		super.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		// ==========================================================
		// 添加界面的组件
		initFrame();
	}

	private void initFrame() {
		super.setLayout(new BorderLayout());
		// 添加一个左右分栏的容器
		JSplitPane mainSplitPane = new JSplitPane();
		super.add(mainSplitPane);
		// ==========================================================
		// 设置分栏器，最大确保右边的区域，100像素
		// 1.获取宽度
		int width = super.getWidth();
		// 2.计算分栏器的位置
		int mainDividerLocation = width - 200;
		// 3.设置分栏器的位置
		mainSplitPane.setDividerLocation(mainDividerLocation);

		// 设置不可重置大小，是为了避免因为改变窗口大小以后，分栏器位置改变
		super.setResizable(false);
		// ==========================================================
		// 增加左边的上下容器
		initLeft(mainSplitPane);

		// 初始化右边的容器
		initRight(mainSplitPane);
	}

	private void initRight(JSplitPane mainSplitPane) {
		JSplitPane rightPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT);
		mainSplitPane.add(rightPane, JSplitPane.RIGHT);

		// 禁止左右拖拉
		mainSplitPane.setDividerSize(0);

		rightPane.setDividerLocation(200);

		// ==========================================================
		// 右上角，应该放一个Panel，用于显示群公共
		JPanel noticePanel = new JPanel(new BorderLayout());
		rightPane.add(noticePanel, JSplitPane.TOP);

		JLabel noticeLabel = new JLabel("群公共");
		noticePanel.add(noticeLabel, BorderLayout.NORTH);
		noticePanel.add(new JLabel("好好学习，天天向上"));

		// ==========================================================
		// 右下角用户列表，需要使用JList，JList也要放到JScrollPane里面
		DefaultListModel<String> dataModel = new DefaultListModel<>();
		JList<String> userList = new JList<>(dataModel);
		JScrollPane userListPane = new JScrollPane(userList);
		rightPane.add(userListPane, JSplitPane.BOTTOM);

		// 可以通过dataModel动态修改JList里面的内容
		for (int i = 0; i < 100; i++) {
			dataModel.addElement("用户: " + i);
		}
	}

	private void initLeft(JSplitPane mainSplitPane) {
		JSplitPane leftPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT);
		mainSplitPane.add(leftPane, JSplitPane.LEFT);

		leftPane.setDividerLocation(400);

		// ==========================================================
		// 上面放一个消息记录的文本框
		JTextArea chatRecord = new JTextArea();
		// 创建一个可以滚动的容器，文本框需要放在这种容器里面才能有滚动条
		JScrollPane chatRecordPane = new JScrollPane(chatRecord);
		leftPane.add(chatRecordPane, JSplitPane.TOP);

		// ==========================================================
		// 下面放一个JPanel，在JPanel的中间放输入信息的文本框、南边放按钮JPanel
		JPanel inputPanel = new JPanel(new BorderLayout());
		leftPane.add(inputPanel, JSplitPane.BOTTOM);

		JTextArea inputArea = new JTextArea();
		JScrollPane inputScrollPane = new JScrollPane(inputArea);
		inputPanel.add(inputScrollPane, BorderLayout.CENTER);

		// 创建一个右边对齐的容器，用来放按钮
		JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
		inputPanel.add(buttonPanel, BorderLayout.SOUTH);

		buttonPanel.add(new JButton("关闭"));
		buttonPanel.add(new JButton("发送"));

	}
}
