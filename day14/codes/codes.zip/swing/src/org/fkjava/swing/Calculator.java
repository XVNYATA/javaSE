package org.fkjava.swing;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class Calculator {

	// TODO 把下面三个变量，改为成员变量，方便在不同的方法中使用
	private static JFrame win;
	private static ScriptEngine se;
	private static JTextField inputField;

	public static void main(String[] args) {
		// 创建一个窗口
		win = new JFrame("超级无敌简单计算器");

		// 设置窗口的大小
		int width = 300;
		int height = 300;
		win.setSize(width, height);

		// 在居中窗口
		// 获取Toolkit，利用Toolkit可以获得屏幕的宽度和高度
		Toolkit toolkit = win.getToolkit();
		Dimension size = toolkit.getScreenSize();
		int screenWidth = size.width;
		int screenHeight = size.height;
		int x = screenWidth / 2 - width / 2;
		int y = screenHeight / 2 - height / 2;
		win.setLocation(x, y);

		// 执行添加组件的操作
		addComponents(win);

		// 把所有组件都添加完成以后，需要显示窗口
		// 如果在运行中修改了组件，也需要再次调用显示窗口的方法
		win.setVisible(true);
	}

	private static void addComponents(JFrame win) {
		// 创建一个脚本引擎管理器
		ScriptEngineManager sem = new ScriptEngineManager();
		// 获得一个JavaScript脚本的执行环境
		se = sem.getEngineByName("JavaScript");

		// 创建一个字体对象，用于设置输入框和按钮的字体
		Font font = new Font(Font.DIALOG, Font.PLAIN, 50);

		// 修改布局
		// win.setLayout(new FlowLayout());

		// Frame默认的BorderLayout正好是我们需要的，所以不需要修改。
		// 只需要调整组件的位置即可
		// 文本框放到一个独立的Panel里面，设置Panel的布局为BorderLayout，并且把Panel放到win的北方

		// 添加一个文本框
		JPanel inputFieldPanel = new JPanel();
		inputFieldPanel.setLayout(new BorderLayout());
		inputField = new JTextField();

		// TODO 禁止在文本框直接输入
		inputField.setEditable(false);// 不可编辑
		inputField.setFocusable(false);// 不可获得焦点

		// 水平右对齐
		inputField.setHorizontalAlignment(JTextField.RIGHT);
		inputField.setFont(font);
		inputFieldPanel.add(inputField);// 把输入框放在Panel的中间
		win.add(inputFieldPanel, BorderLayout.NORTH);// 放在win的北方

		// 按钮全部放到一个独立的Panel里面，设置Panel的布局为GridLayout
		JPanel buttonPanel = new JPanel();
		buttonPanel.setLayout(new GridLayout(4, 4));
		// 把按钮的Panel放到win的中间
		win.add(buttonPanel);
		// 循环添加16个按钮，每个按钮显示的内容是不同的
		String[] labels = new String[] { "7", "8", "9", "+", "4", "5", "6",
				"-", "1", "2", "3", "*", "0", ".", "=", "/" };

		// 添加一个鼠标监听器，用于监听按钮的动作
		MouseListener buttonClickListener = new MouseAdapter() {

			@Override
			public void mouseClicked(MouseEvent e) {
				// 只对此方法感兴趣，其他的不感兴趣，但是必须有方法实现（即便留空方法）
				// 把按钮的文字，放到输入框中
				// 必须知道是哪个按钮被点击！
				Object source = e.getSource();
				// System.out.println("单击：" + source);
				JButton button = (JButton) source;
				// String label = button.getLabel();
				String label = button.getText();

				// TODO 处理输入的操作，放在一个方法里面，方便和键盘事件共享相同的代码
				processInput(label);
			}
		};

		for (String label : labels) {
			JButton b = new JButton(label);
			buttonPanel.add(b);
			b.setFont(font);

			// 给按钮添加鼠标监听器
			b.addMouseListener(buttonClickListener);

			// TODO 为了能够让窗口获得键盘事件，必须禁用按钮的获得焦点的能力。
			// 焦点在哪个组件上面，按键的时候，就是这个组件获得键盘事件
			b.setFocusable(false);
		}

		// 关闭窗口的事件，也需要程序员自己处理，否则窗口无法被关闭！
		win.addWindowListener(new WindowAdapter() {

			/**
			 * 点击 窗口的 【关闭】 按钮的时候，会触发此事件
			 * 
			 * @see java.awt.event.WindowAdapter#windowClosing(java.awt.event.WindowEvent)
			 */
			@Override
			public void windowClosing(WindowEvent e) {
				// 把窗口销毁掉
				win.dispose();
			}
		});

		// TODO 给窗口添加键盘事件
		win.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				// 完成一次打字动作，触发此事件
				char c = e.getKeyChar();
				if (c >= '0' && c <= '9') {
					// 表示按数字键
					processInput("" + c);
				} else if (c == '+' || c == '-' || c == '*' || c == '/') {
					// 表示运算符
					processInput("" + c);
				} else if (c == '=') {
					// 表示计算结果
					processInput("" + c);
				} else if (c == 8) {
					// 退格键，删除最后一个字符
					String text = inputField.getText();
					if (!text.equals("")) {
						text = text.substring(0, text.length() - 1);
						inputField.setText(text);
					}
				} else if (c == 27) {
					// ESC键，清空内容
					inputField.setText("");
				}
			}
		});
	}

	// TODO 统一的处理输入的方法
	protected static void processInput(String label) {
		String text = inputField.getText();
		if (label.equals("=")) {
			// 计算结果
			try {
				Object result = se.eval(text);
				// 如果没有出现异常，表示计算正确，把result转换为String设置到输入框
				inputField.setText(result.toString());
			} catch (ScriptException e1) {
				e1.printStackTrace();

				// 计算出现异常，通常是因为表达式不正确，提示计算出错
				JOptionPane.showMessageDialog(win, "计算出错: " + e1.getMessage(),
						"错误提示", JOptionPane.ERROR_MESSAGE);
			}
		} else {
			// 把按钮的文字，添加到输入框
			text = text + label;
			inputField.setText(text);
		}
	}
}
