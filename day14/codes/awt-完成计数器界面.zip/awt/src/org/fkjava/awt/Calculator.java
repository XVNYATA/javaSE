package org.fkjava.awt;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.Panel;
import java.awt.TextField;
import java.awt.Toolkit;

public class Calculator {

	public static void main(String[] args) {
		// 创建一个窗口
		Frame win = new Frame("超级无敌简单计算器");

		// 设置窗口的大小
		int width = 300;
		int height = 300;
		win.setSize(width, height);

		// 在居中窗口
		// 获取Toolkit，利用Toolkit可以获得屏幕的宽度和高度
		Toolkit toolkit = win.getToolkit();
		Dimension size = toolkit.getScreenSize();
		int screenWidth = size.width;
		int screenHeight = size.height;
		int x = screenWidth / 2 - width / 2;
		int y = screenHeight / 2 - height / 2;
		win.setLocation(x, y);

		// 执行添加组件的操作
		addComponents(win);

		// 把所有组件都添加完成以后，需要显示窗口
		// 如果在运行中修改了组件，也需要再次调用显示窗口的方法
		win.setVisible(true);
	}

	private static void addComponents(Frame win) {
		//创建一个字体对象，用于设置输入框和按钮的字体
		Font font = new Font(Font.DIALOG, Font.PLAIN, 50);
		
		// 修改布局
		// win.setLayout(new FlowLayout());

		// Frame默认的BorderLayout正好是我们需要的，所以不需要修改。
		// 只需要调整组件的位置即可
		// 文本框放到一个独立的Panel里面，设置Panel的布局为BorderLayout，并且把Panel放到win的北方

		// 添加一个文本框
		Panel inputFieldPanel = new Panel();
		inputFieldPanel.setLayout(new BorderLayout());
		TextField inputField = new TextField();
		inputField.setFont(font);
		inputFieldPanel.add(inputField);// 把输入框放在Panel的中间
		win.add(inputFieldPanel, BorderLayout.NORTH);// 放在win的北方

		// 按钮全部放到一个独立的Panel里面，设置Panel的布局为GridLayout
		Panel buttonPanel = new Panel();
		buttonPanel.setLayout(new GridLayout(4, 4));
		//把按钮的Panel放到win的中间
		win.add(buttonPanel);
		// 循环添加16个按钮，每个按钮显示的内容是不同的
		String[] labels = new String[] { 
				"7", "8", "9", "+", 
				"4", "5", "6", "-", 
				"1", "2", "3", "*", 
				"0", ".", "=", "/" };
		for (String label : labels) {
			Button b = new Button(label);
			buttonPanel.add(b);
			b.setFont(font);
		}
	}
}
