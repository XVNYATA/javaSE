package org.fkjava.awt;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.Panel;
import java.awt.TextField;
import java.awt.Toolkit;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;
import javax.swing.JOptionPane;

import jdk.nashorn.internal.scripts.JO;

public class Calculator {

	public static void main(String[] args) {
		// 创建一个窗口
		Frame win = new Frame("超级无敌简单计算器");

		// 设置窗口的大小
		int width = 300;
		int height = 300;
		win.setSize(width, height);

		// 在居中窗口
		// 获取Toolkit，利用Toolkit可以获得屏幕的宽度和高度
		Toolkit toolkit = win.getToolkit();
		Dimension size = toolkit.getScreenSize();
		int screenWidth = size.width;
		int screenHeight = size.height;
		int x = screenWidth / 2 - width / 2;
		int y = screenHeight / 2 - height / 2;
		win.setLocation(x, y);

		// 执行添加组件的操作
		addComponents(win);

		// 把所有组件都添加完成以后，需要显示窗口
		// 如果在运行中修改了组件，也需要再次调用显示窗口的方法
		win.setVisible(true);
	}

	private static void addComponents(Frame win) {
		// 创建一个脚本引擎管理器
		ScriptEngineManager sem = new ScriptEngineManager();
		// 获得一个JavaScript脚本的执行环境
		ScriptEngine se = sem.getEngineByName("JavaScript");

		// 创建一个字体对象，用于设置输入框和按钮的字体
		Font font = new Font(Font.DIALOG, Font.PLAIN, 50);

		// 修改布局
		// win.setLayout(new FlowLayout());

		// Frame默认的BorderLayout正好是我们需要的，所以不需要修改。
		// 只需要调整组件的位置即可
		// 文本框放到一个独立的Panel里面，设置Panel的布局为BorderLayout，并且把Panel放到win的北方

		// 添加一个文本框
		Panel inputFieldPanel = new Panel();
		inputFieldPanel.setLayout(new BorderLayout());
		TextField inputField = new TextField();
		inputField.setFont(font);
		inputFieldPanel.add(inputField);// 把输入框放在Panel的中间
		win.add(inputFieldPanel, BorderLayout.NORTH);// 放在win的北方

		// 按钮全部放到一个独立的Panel里面，设置Panel的布局为GridLayout
		Panel buttonPanel = new Panel();
		buttonPanel.setLayout(new GridLayout(4, 4));
		// 把按钮的Panel放到win的中间
		win.add(buttonPanel);
		// 循环添加16个按钮，每个按钮显示的内容是不同的
		String[] labels = new String[] { "7", "8", "9", "+", "4", "5", "6",
				"-", "1", "2", "3", "*", "0", ".", "=", "/" };

		// 添加一个鼠标监听器，用于监听按钮的动作
		MouseListener buttonClickListener = new MouseAdapter() {

			@Override
			public void mouseClicked(MouseEvent e) {
				// 只对此方法感兴趣，其他的不感兴趣，但是必须有方法实现（即便留空方法）
				// 把按钮的文字，放到输入框中
				// 必须知道是哪个按钮被点击！
				Object source = e.getSource();
				// System.out.println("单击：" + source);
				Button button = (Button) source;
				String label = button.getLabel();

				String text = inputField.getText();
				if (label.equals("=")) {
					// 计算结果
					try {
						Object result = se.eval(text);
						// 如果没有出现异常，表示计算正确，把result转换为String设置到输入框
						inputField.setText(result.toString());
					} catch (ScriptException e1) {
						e1.printStackTrace();

						// 计算出现异常，通常是因为表达式不正确，提示计算出错
						JOptionPane.showMessageDialog(win,
								"计算出错: " + e1.getMessage(), "错误提示",
								JOptionPane.ERROR_MESSAGE);
					}
				} else {
					// 把按钮的文字，添加到输入框
					text = text + label;
					inputField.setText(text);
				}
			}
		};

		for (String label : labels) {
			Button b = new Button(label);
			buttonPanel.add(b);
			b.setFont(font);

			// 给按钮添加鼠标监听器
			b.addMouseListener(buttonClickListener);
		}

		// 关闭窗口的事件，也需要程序员自己处理，否则窗口无法被关闭！
		win.addWindowListener(new WindowAdapter() {

			/**
			 * 点击 窗口的 【关闭】 按钮的时候，会触发此事件
			 * 
			 * @see java.awt.event.WindowAdapter#windowClosing(java.awt.event.WindowEvent)
			 */
			@Override
			public void windowClosing(WindowEvent e) {
				// 把窗口销毁掉
				win.dispose();
			}
		});
	}
}
