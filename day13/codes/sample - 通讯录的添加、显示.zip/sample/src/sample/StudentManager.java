package sample;

public interface StudentManager {

	/**
	 * 添加一个学生到集合,key为学生的name
	 * 
	 * @param stu
	 *            学生
	 * @return 成功返回true 失败false
	 * */
	public boolean addStudent(Student stu);

	/**
	 * 从集合里面删除一个学生,根据id去找到学生然后删除
	 * 
	 * @param id
	 *            学生id
	 * @return 成功返回true 失败false
	 * */
	public boolean removeStudent(Integer id);

	/**
	 * 修改一个学生的所有信息,通过id找到学生,然后修改
	 * 
	 * @param Stu
	 *            学生对象（包括需要修改的信息）
	 * */
	public void modifyStudent(Student stu);

	/**
	 * 查询所有学生信息打印在控制台
	 * */
	public void viewAllStudent();

	/**
	 * 根据学生姓名查询学生信息(假设姓名不会重复)
	 * 
	 * @return 包含学生信息的Student对象
	 * */
	public Student findStudentByName(String name);
}
