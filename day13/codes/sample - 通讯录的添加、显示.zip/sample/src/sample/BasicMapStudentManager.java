package sample;

import java.util.HashMap;
import java.util.Map;

public class BasicMapStudentManager implements StudentManager {

	private Map<String, Student> map = new HashMap<>();

	@Override
	public boolean addStudent(Student stu) {
		// 1.判断学生的name是否已经在map里面，如果已经在表示重名。程序现在不允许重名。
		// 在这种情况下应该提示用户出错、要求重新输入姓名。
		if (map.containsKey(stu.getName())) {
			// 表示map已经包含了name
			System.out.println("学生的姓名重复: " + stu.getName());
			return false;
		}

		// 2.找到map里面已有的Student里面，最大的id
		int maxId = 0;
		// 遍历整个map找所有student的id，检查是否比maxId要大
		for (Map.Entry<String, Student> entry : map.entrySet()) {
			if (entry.getValue().getId() > maxId) {
				// 学生的id更大
				maxId = entry.getValue().getId();
			}
		}

		// 3.把最大的id加一，就变成了新的Student的id
		int newId = maxId + 1;
		stu.setId(newId);

		// 4.把学生的name作为key，把Student添加到map里面
		map.put(stu.getName(), stu);
		return true;
	}

	@Override
	public boolean removeStudent(Integer id) {
		return false;
	}

	@Override
	public void modifyStudent(Student stu) {

	}

	@Override
	public void viewAllStudent() {
		// 循环map，把map里面的内容，全部输入一下。
		map.forEach((name, student) -> {
			System.out.println("ID : " + student.getId());
			System.out.println("姓名: " + name);
			System.out.println("性别: " + student.getSex());
			System.out.println("地址: " + student.getAddress());
			System.out.println("电话: " + student.getPhone());
			System.out.println("邮件: " + student.getEmail());
			System.out.println("------------------------------------------");
		});
	}

	@Override
	public Student findStudentByName(String name) {
		return null;
	}

}
