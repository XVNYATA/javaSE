package sample;

import java.util.Scanner;

public class TestStudentManager {

	private static Scanner scanner = new Scanner(System.in);
	private static StudentManager sm;

	public static void main(String[] args) {

		// 创建StudentManager的实现类的实例
		sm = new BasicMapStudentManager();

		while (true) {
			System.out.println("请输入命令执行操作 : ");
			System.out
					.println("    添加( a )  删除( r )  修改( m )  查看所有( v )  查找( f )");
			// 如果用户输入的是a，表示添加一个学生，接下来就需要输入学生的各种信息，进行添加
			// name,sex,address,phone,email
			String cmd = scanner.next();
			switch (cmd) {
			case "a":
				addStudent();
				break;

			case "v":
				viewAllStudent();
				break;
			default:
				System.out.println("未知命令: " + cmd);
				break;
			}
		}
	}

	private static void viewAllStudent() {
		sm.viewAllStudent();
	}

	private static void addStudent() {
		// name
		System.out.println("请输入学生的姓名: ");
		String name = scanner.next();

		// sex
		System.out.println("请输入学生的性别，可选的为 男 、 女: ");
		String sex = scanner.next();

		// address
		System.out.println("请输入学生的家庭地址: ");
		String address = scanner.next();

		// phone
		System.out.println("请输入学生的手机号码: ");
		String phone = scanner.next();

		// email
		System.out.println("请输入学生的邮件地址: ");
		String email = scanner.next();

		// 利用把输入的信息，创建一个Student对象
		Student s = new Student(name, sex, address, phone, email);

		// 调用 StudentManager里面的方法，把学生添加到通讯录里面
		sm.addStudent(s);
	}
}
