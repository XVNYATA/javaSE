package sample;

import java.util.InputMismatchException;
import java.util.Scanner;

public class TestStudentManager {

	private static Scanner scanner = new Scanner(System.in);
	private static StudentManager sm;

	public static void main(String[] args) {

		// 创建StudentManager的实现类的实例
		sm = new BasicMapStudentManager();

		while (true) {
			System.out.println("请输入命令执行操作 : ");
			System.out
					.println("    添加( a )  删除( r )  修改( m )  查看所有( v )  查找( f )");
			// 如果用户输入的是a，表示添加一个学生，接下来就需要输入学生的各种信息，进行添加
			// name,sex,address,phone,email
			String cmd = scanner.next();
			switch (cmd) {
			case "a":
				addStudent();
				break;

			case "r":
				removeStudent();
				break;

			case "m":
				modifyStudent();
				break;

			case "v":
				viewAllStudent();
				break;
			default:
				System.out.println("未知命令: " + cmd);
				break;
			}
		}
	}

	private static void modifyStudent() {
		// 输入要修改的学生的ID，然后提示输入新的学生电话（这里只是修改电话，不搞太复杂）

		while (true) {
			try {
				System.out.println("请输入要修改的学生的ID");
				// 预期这里应该返回一个int，如果没有返回int，一定就是预期之外的，属于异常！
				int id = scanner.nextInt();

				System.out.println("请输入学生新的地址");
				String address = scanner.next();

				Student student = new Student(id, address);
				sm.modifyStudent(student);

				// 修改成功，表示没有问题！不需要继续循环，直接break
				break;
			} catch (InputMismatchException ex) {

				// 打印异常栈跟踪信息
				ex.printStackTrace();

				// 如果nextInt出现异常，那么输入给scanner的字符串不会被使用，于是在下次nextInt的时候，获取到原来的信息
				// 所以这里需要调用next方法使用掉输入的错误的内容
				String x = scanner.next();

				System.out.println("输入的字符 " + x + " 无法转换为整数，请重新输入");
				// 出现异常，表示需要循环，回到上面的输入再执行一次，需要循环，直接死循环
			}
		}
	}

	private static void removeStudent() {
		while (true) {
			System.out.println("请输入要删除的学生的ID进行删除");
			// 接收一个字符串，并且把字符串转换为int类型的id
			String s = scanner.next();
			if (s.matches("^\\d+$")) {
				int id = Integer.parseInt(s);

				// 调用方法删除
				sm.removeStudent(id);
				break;
			} else {
				System.out.println("输入的 " + s + " 不是数字，无法转换为int");
			}
		}
	}

	private static void viewAllStudent() {
		sm.viewAllStudent();
	}

	private static void addStudent() {
		// name
		System.out.println("请输入学生的姓名: ");
		String name = scanner.next();

		// sex
		System.out.println("请输入学生的性别，可选的为 男 、 女: ");
		String sex = scanner.next();

		// address
		System.out.println("请输入学生的家庭地址: ");
		String address = scanner.next();

		// phone
		System.out.println("请输入学生的手机号码: ");
		String phone = scanner.next();

		// email
		System.out.println("请输入学生的邮件地址: ");
		String email = scanner.next();

		// 利用把输入的信息，创建一个Student对象
		Student s = new Student(name, sex, address, phone, email);

		// 调用 StudentManager里面的方法，把学生添加到通讯录里面
		sm.addStudent(s);
	}
}
