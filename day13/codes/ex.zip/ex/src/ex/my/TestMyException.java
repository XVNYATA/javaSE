package ex.my;

public class TestMyException {

	public static void main(String[] args) {
		try {
			test();
		} catch (InvalidPasswordException e) {
			e.printStackTrace();
		} catch (BalanceNotEnoughException e) {
			e.printStackTrace();
		}

		// 使用Java 7的multi-catch代码块的语法，处理异常，使得异常处理更简洁
		try {
			test();
		} catch (InvalidPasswordException | BalanceNotEnoughException e) {
			e.printStackTrace();
		}
	}

	private static void test() throws BalanceNotEnoughException,
			InvalidPasswordException {

		throw new InvalidPasswordException("输入的密码和实际的密码不一致");
	}
}
