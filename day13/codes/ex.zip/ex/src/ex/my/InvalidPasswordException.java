package ex.my;

public class InvalidPasswordException extends IllegalArgumentException {

	public InvalidPasswordException() {
		super();
	}

	public InvalidPasswordException(String message, Throwable cause) {
		super(message, cause);
	}

	public InvalidPasswordException(String s) {
		super(s);
	}

	public InvalidPasswordException(Throwable cause) {
		super(cause);
	}

}
