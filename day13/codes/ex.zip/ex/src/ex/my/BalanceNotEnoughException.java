package ex.my;

public class BalanceNotEnoughException extends RuntimeException {

}
