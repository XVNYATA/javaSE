package ex;

import java.util.ArrayList;
import java.util.List;

public class TestException {

	public static void main(String[] args) {
		int[] arr = new int[] { 1, 2, 3 };
		List<String> list = new ArrayList<>();
		list.add("ab");
		list.add("cd");

		try {
			arr[5] = 100;
			String s = list.get(4);
			System.out.println("s的值：" + s);
		} catch (ArrayIndexOutOfBoundsException ex) {
			// 子类的catch要放在(父类)前面
			System.out.println("数组索引越界");
		} catch (IndexOutOfBoundsException x) {
			System.out.println("索引超出边界异常");
		}
		System.out.println("程序的最后要输出！");
	}
}
