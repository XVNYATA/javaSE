package ex.handle;

import java.io.IOException;
import java.util.Scanner;

/**
 * 演示异常处理的综合练习
 * 
 * @author lwq
 *
 */
public class TestExceptionHandle {

	private static Scanner scanner = new Scanner(System.in);

	public static void main(String[] args) {

		try {
			test();
		} catch (NumberFormatException e) {
			System.out.println("数字格式化异常");
			e.printStackTrace();
		} catch (NullPointerException e) {
			System.out.println("空指针异常");
			e.printStackTrace();
		} catch (RuntimeException e) {
			System.out.println("运行时异常");
			e.printStackTrace();
		} catch (IOException e) {
			System.out.println("输入输出异常");
			e.printStackTrace();
		} catch (Exception e) {
			System.out.println("其他异常");
			e.printStackTrace();
		}
	}

	private static void test() throws Exception, RuntimeException, IOException,
			NullPointerException, NumberFormatException {

		String x = scanner.next();
		switch (x) {
		case "n":
			// 产生一个空指针异常
			throw new NullPointerException("自己产生的一个空指针异常！");

			// throw是用来把异常对象抛出给调用者的一个关键字
			// throw以后，方法会结束，所以下面不需要break。
			// break;
		case "r":
			throw new RuntimeException("自己产生的运行时异常");
		case "f":

			// x的值是“f”，执行parseInt一定会出现异常
			int i = Integer.parseInt(x);
			break;
		}
	}
}
