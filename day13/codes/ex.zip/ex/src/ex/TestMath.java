package ex;

public class TestMath {

	public static void main(String[] args) {
		System.out.println("程序开始");

		int x = 5;
		int y = 0;

		try {
			int z = x / y;

			// 出现异常的时候，try代码块会马上结束，跳到catch代码块，所以下面的语句不会输出
			System.out.println("try代码块结束");
		} catch (ArithmeticException e) {
			System.out.println("除法出现异常，可能是除数为0");
		}

		System.out.println("第一个try catch 结束");

		System.out.println("============================");
		// 如果有finally代码块，不管是否出现异常，finally都会执行
		try {
			int z = x / 0;
			System.out.println("try代码块结束");
		} catch (ArithmeticException e) {
			System.out.println("除法出现异常，可能是除数为0");
		} finally {
			System.out.println("最终执行的代码块");
		}

		System.out.println("第二个try catch 结束");

		System.out.println("============================");
		// try后面如果不想处理异常，可以直接写finally，异常最终由【调用者】来处理
		// TestMath的调用者是java命令！
		// 出现异常以后，因为当前方法没有处理异常，会自动把异常抛出给调用者。
		// 这样会导致方法直接结束！
		try {
			int z = x / 0;
			System.out.println("try代码块结束");
		} finally {
			System.out.println("最终执行的代码块");
		}

		System.out.println("程序结束");
	}
}
