package ex.io;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 * 老的异常处理
 * 
 * @author lwq
 *
 */
public class TestOld {

	public static void main(String[] args) {
		// 读取文件
		// 创建文件对象
		File file = new File("/tmp/a.txt");
		FileInputStream fis = null;
		InputStreamReader isr = null;
		try {
			// 创建文件输入流，文件输入流是一个资源，必须调用close方法关闭
			fis = new FileInputStream(file);

			// 把文件输入流包装成一个InputStreamReader
			isr = new InputStreamReader(fis);

		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			// 先申请的资源，必须后释放
			// 后申请的资源，必须先释放
			// 栈的顺序
			try {
				if (isr != null) {
					isr.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}

			try {
				if (fis != null) {
					fis.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}

		}
	}
}
