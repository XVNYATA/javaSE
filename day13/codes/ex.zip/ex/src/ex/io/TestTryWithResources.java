package ex.io;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 * 老的异常处理
 * 
 * @author lwq
 *
 */
public class TestTryWithResources {

	public static void main(String[] args) {
		// 读取文件
		// 创建文件对象
		File file = new File("/tmp/a.txt");
		try (FileInputStream fis = new FileInputStream(file);
				InputStreamReader isr = new InputStreamReader(fis);) {
			// 处理需要处理的业务……
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
		}

		// close方法、try代码块、catch代码块、finally代码块的执行顺序
		System.out.println("======================================");
		try (MyResource m1 = new MyResource(); MyResource m2 = new MyResource()) {
			System.out.println("try代码块里面的输出");
			int i = 5 / 0;
		} catch (Exception e) {
			System.out.println("catch代码块的输出");
		} finally {
			System.out.println("finally代码块的输出");
		}
	}
}
