package ex.io;

public class MyResource implements AutoCloseable {

	public MyResource() {
		System.out.println(this + " : 创建了资源");
	}

	@Override
	public void close() {
		System.out.println(this + " : close方法被调用");
	}
}
