package ex;

public class TestReturn {

	public static void main(String[] args) {
		String s = test1();
		System.out.println(s);
	}

	private static String test1() {
		try {
			int x = 5 / 0;
			System.out.println("try代码块返回之前");
			return "无异常返回";
		} catch (ArithmeticException e) {
			System.out.println("catch的返回之前");
			return "异常处理返回";
		} finally {
			System.out.println("finally返回之前");

			// 不建议在finally里面返回
			return "最终返回";
		}
	}
}
