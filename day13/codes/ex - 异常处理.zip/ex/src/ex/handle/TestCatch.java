package ex.handle;

public class TestCatch {

	public static void main(String[] args) {
		String x = "a";
		try {
			// 执行parseInt方法的时候，此方法声明了抛出NumberFormatException
			// parseInt方法本身没有catch这个异常来进行处理，而是交给程序员来处理
			int i = Integer.parseInt(x);
		} catch (NumberFormatException ex) {
			// 处理异常的代码……
			// 在不确定异常该如何处理的时候，可以简单把异常的栈信息打印一下
			ex.printStackTrace();
		}
	}
}
