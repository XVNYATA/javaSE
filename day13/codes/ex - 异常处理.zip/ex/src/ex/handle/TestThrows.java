package ex.handle;

import java.io.IOException;
import java.sql.SQLException;

public class TestThrows {

	public static void main(String[] args) {
		// unchecked异常随便处理
		test1();

		// 对于使用的地方来讲，是不清楚方法是否会抛出异常，只要方法声明了抛出，那么就必须处理！
		try {
			test2();
		} catch (IOException e) {
			e.printStackTrace();
		}

		try {
			test3();
		} catch (NullPointerException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (RuntimeException e) {
			System.out.println("运行时异常");
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	/**
	 * 文档注释
	 * 
	 * @throws Exception
	 *             异常
	 * @throws IOException
	 *             输入输出异常
	 * @throws SQLException
	 *             数据库异常
	 * @throws RuntimeException
	 *             运行时异常
	 * @throws NullPointerException
	 *             空指针异常
	 */
	private static void test3() throws Exception, IOException, SQLException,
			RuntimeException, NullPointerException {
		int x = 5 / 0;
	}

	/**
	 * 
	 * @throws IOException
	 *             可能会抛出IOException
	 */
	private static void test2() throws IOException {
	}

	private static void test1() throws NullPointerException {
	}
}
