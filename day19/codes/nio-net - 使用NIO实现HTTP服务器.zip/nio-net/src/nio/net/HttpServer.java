package nio.net;

import java.io.File;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.channels.FileChannel;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.nio.charset.Charset;
import java.nio.file.Paths;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class HttpServer {

	private static ExecutorService es = Executors.newFixedThreadPool(50);
	private static Charset cs = Charset.forName("UTF-8");

	public static void main(String[] args) {
		try {
			// 1.打开一个ServerSocketChannel
			ServerSocketChannel serverSocketChannel = ServerSocketChannel
					.open();

			// 2.设置参数
			serverSocketChannel.configureBlocking(false);

			// 3.绑定端口
			serverSocketChannel.bind(new InetSocketAddress(8000));

			System.out.println("服务器绑定端口成功");

			// 4.注册接受事件
			Selector selector = Selector.open();
			serverSocketChannel.register(selector, SelectionKey.OP_ACCEPT);

			// 启动一个线程，不断接受新的连接
			Thread t = new Thread(() -> {
				processEvent(selector);
			});

			t.start();

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private static void processEvent(Selector selector) {
		// 不断选择事件进行处理
		while (true) {
			try {
				// 1.选择事件
				selector.select();

				// 2.获取已经选中的事件
				Set<SelectionKey> keys = selector.selectedKeys();

				// 3.处理选中的事件
				for (SelectionKey key : keys) {
					// 3.1.判断key是否为 acceptable ，如果是表示为连接事件
					if (key.isAcceptable()) {
						ServerSocketChannel serverSocketChannel = (ServerSocketChannel) key
								.channel();

						// 接受连接
						SocketChannel socketChannel = serverSocketChannel
								.accept();

						if (socketChannel != null) {
							// 表示连接成功
							// 把SocketChannel设置为非阻塞的，并且注册读事件
							socketChannel.configureBlocking(false);

							socketChannel.register(selector,
									SelectionKey.OP_READ);
						}
					} else {
						// 非连接事件，就认为是普通的读写操作
						// System.out.println(key.isReadable());// true

						SocketChannel socketChannel = (SocketChannel) key
								.channel();

						// 获取附加到SelectionKey里面的缓冲器对象
						ByteBuffer buffer = (ByteBuffer) key.attachment();
						if (buffer == null) {
							buffer = ByteBuffer.allocate(1024);
						}

						// 读取数据放到缓冲里面
						socketChannel.read(buffer);

						// 判断数据是否已经完整
						if (buffer.get(buffer.position() - 4) == '\r'
								&& buffer.get(buffer.position() - 3) == '\n'
								&& buffer.get(buffer.position() - 2) == '\r'
								&& buffer.get(buffer.position() - 1) == '\n') {
							// 数据完整
							final ByteBuffer bb = buffer;
							Runnable task = () -> {
								try {
									processRequest(socketChannel, bb);

									// 处理完请求以后，还需要关闭Socket通道
									socketChannel.close();

									// 数据处理完成以后，清空缓冲
									bb.clear();
								} catch (IOException ex) {
									ex.printStackTrace();
								}
							};
							es.submit(task);
						}
					}
				}

				// 4.处理完成以后，必须把事件全部清空
				keys.clear();
			} catch (IOException e) {
				e.printStackTrace();
			}

		}
	}

	private static void processRequest(SocketChannel socketChannel,
			ByteBuffer buffer) throws IOException {
		buffer.flip();
		for (int i = 0; i < buffer.limit(); i++) {
			if (buffer.get(i) == '\r' && buffer.get(i + 1) == '\n') {
				// 表示i的位置，正好是第一行的结束
				// 直接把limit设置为i
				buffer.limit(i);
			}
		}

		// 直接使用Charset对buffer进行解码
		Charset cs = Charset.forName("ASCII");
		CharBuffer cb = cs.decode(buffer);
		// System.out.println(cb.toString());
		String uri = cb.toString();
		uri = uri.substring(uri.indexOf(" ") + 1);
		uri = uri.substring(0, uri.indexOf(" "));

		File file = new File("/tmp/http", uri);
		if (file.exists()) {
			sendFile(file, socketChannel);
		} else {
			send404(file, socketChannel);
		}
	}

	private static void sendFile(File file, SocketChannel socketChannel)
			throws IOException {
		try (FileChannel fc = FileChannel.open(Paths.get(file.toURI()))) {

			// System.out.println("发送文件: " + file);
			// 拼响应头
			StringBuilder headerBuilder = new StringBuilder();
			headerBuilder.append("HTTP/1.1 200 OK\r\n");
			headerBuilder.append("Content-Type: text/html; charset=UTF-8\r\n");
			headerBuilder.append("Content-Length: ").append(file.length())
					.append("\r\n");
			headerBuilder.append("\r\n");

			// 写响应头
			ByteBuffer head = cs.encode(headerBuilder.toString());
			// head.flip();
			socketChannel.write(head);

			// 发送文件
			fc.transferTo(0, file.length(), socketChannel);
			// System.out.println("文件 " + file + " 发送完成");
		}
	}

	private static void send404(File file, SocketChannel socketChannel)
			throws IOException {
		String content = "文件 " + file.getAbsolutePath() + " 没有找到";
		ByteBuffer data = cs.encode(content);

		// 拼响应头
		StringBuilder headerBuilder = new StringBuilder();
		headerBuilder.append("HTTP/1.1 404 File Not Found\r\n");
		headerBuilder.append("Content-Type: text/html; charset=UTF-8\r\n");
		headerBuilder.append("Content-Length: ").append(data.limit())
				.append("\r\n");
		headerBuilder.append("\r\n");

		// 写响应头
		// System.out.println("写响应头");
		ByteBuffer head = cs.encode(headerBuilder.toString());
		socketChannel.write(head);

		// System.out.println("写响应体");
		// 写内容
		socketChannel.write(data);
		// System.out.println("响应完成");
	}
}
