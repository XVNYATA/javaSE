package nio.net;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Iterator;
import java.util.Set;

public class TestSocketChannel {

	public static void main(String[] args) throws IOException {
		// 1.打开ServerSocketChannel
		ServerSocketChannel serverChannel = ServerSocketChannel.open();

		// 2.设置Socket的参数
		// 默认情况下可以不设置，参数只是为了优化性能。

		// setOption是设置性能优化选项的方法，可以省略。

		// 为了实现选择的能力，必须要配置一个参数：

		// 表示配置非阻塞IO，NIO最直接的性能提升，就是非阻塞IO。
		// 如果没有配置这个参数，那么后面的选择器无法正常选择。
		serverChannel.configureBlocking(false);

		// 3.绑定端口
		InetSocketAddress port = new InetSocketAddress(8000);
		serverChannel.bind(port);

		// 4.注册选择事件
		// 打开一个选择器
		Selector selector = Selector.open();

		// 注册连接操作，如果有连接操作，则进行处理
		serverChannel.register(selector, SelectionKey.OP_ACCEPT);

		System.out.println("开始接受连接");

		while (true) {
			// 选择已有的事件，如果没有任何的事件，阻塞
			int i = selector.select();
			System.out.println("事件数量：" + i);
			// 把选中的事件获取出来，进行处理
			Set<SelectionKey> keys = selector.selectedKeys();
			System.out.println("得到选择的事件：" + keys.size());

			// 选中以后，就对keys进行遍历
			Iterator<SelectionKey> it = keys.iterator();
			while (it.hasNext()) {
				// 注册读取事件
				SelectionKey key = it.next();

				// System.out.println(key.isAcceptable());
				// System.out.println(key.isConnectable());
				// System.out.println(key.isReadable());
				// System.out.println(key.isWritable());

				if (key.isAcceptable()) {
					// 表示这个是接受事件
					ServerSocketChannel serverSocketChannel = (ServerSocketChannel) key
							.channel();
					SocketChannel channel = serverSocketChannel.accept();
					if (channel != null) {
						// 设置为异步的NIO
						channel.configureBlocking(false);
						// 注册读事件
						channel.register(selector, SelectionKey.OP_READ);
					}
				} else {
					// System.out.println(key.channel() instanceof
					// SocketChannel);
					SocketChannel channel = (SocketChannel) key.channel();
					// 附加一个缓冲给key，第一次的read，不一定能够把数据读取完整，为了保证数据的完整，可能需要读多次
					Object att = key.attachment();
					ByteBuffer buffer;
					if (att == null) {
						buffer = ByteBuffer.allocate(8 * 1024);
						key.attach(buffer);
					} else {
						buffer = (ByteBuffer) att;
					}
					// 利用附加的缓冲来进行数据的读写操作
					channel.read(buffer);

					// 判断buffer是否连续两个 \r\n 结尾，如果是表示数据完整！
					if (buffer.get(buffer.position() - 4) == '\r'
							&& buffer.get(buffer.position() - 3) == '\n'
							&& buffer.get(buffer.position() - 2) == '\r'
							&& buffer.get(buffer.position() - 1) == '\n') {
						// 表示数据已经完整！
						// System.out.println("数据已经完整");

						String content = "服务器返回的信息";
						byte[] data = content.getBytes("UTF-8");

						StringBuilder headerBuilder = new StringBuilder();
						headerBuilder.append("HTTP/1.1 200 OK\r\n");
						headerBuilder
								.append("Content-Type: text/html; charset=UTF-8\r\n");
						headerBuilder.append("Content-Length: ")
								.append(data.length).append("\r\n");
						headerBuilder.append("\r\n");

						buffer.clear();
						buffer.put(headerBuilder.toString().getBytes());
						buffer.put(data);

						buffer.flip();
						channel.write(buffer);

						// 写完数据，把channel关闭
						channel.close();
					} else {
						// System.out.println("数据不完整");
					}
				}
			}
			keys.clear();
		}
	}
}
