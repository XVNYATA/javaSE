package nio.net;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.util.Set;

public class TestServerSocketChannel {

	public static void main(String[] args) throws IOException {
		// 1.打开ServerSocketChannel
		ServerSocketChannel serverChannel = ServerSocketChannel.open();

		// 2.设置Socket的参数
		// 默认情况下可以不设置，参数只是为了优化性能。

		// setOption是设置性能优化选项的方法，可以省略。

		// 为了实现选择的能力，必须要配置一个参数：

		// 表示配置非阻塞IO，NIO最直接的性能提升，就是非阻塞IO。
		// 如果没有配置这个参数，那么后面的选择器无法正常选择。
		serverChannel.configureBlocking(false);

		// 3.绑定端口
		InetSocketAddress port = new InetSocketAddress(8000);
		serverChannel.bind(port);

		// 4.注册选择事件
		// 打开一个选择器
		Selector selector = Selector.open();

		// 注册连接操作，如果有连接操作，则进行处理
		serverChannel.register(selector, SelectionKey.OP_ACCEPT);

		System.out.println("开始接受连接");

		// 选择已有的事件，如果没有任何的事件，阻塞
		int i = selector.select();
		System.out.println("事件数量：" + i);
		// 把选中的事件获取出来，进行处理
		Set<SelectionKey> keys = selector.selectedKeys();
		System.out.println("得到选择的事件：" + keys.size());
	}
}
