package chat;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class LoginFrame extends MyFrame {

	private ChatClient client;

	public LoginFrame(ChatClient client) {

		super("聊天登陆界面");
		this.client = client;

		// 设置窗口的大小和位置
		setWindowSizeAndLocation(300, 200);

		// 设置处理关闭事件。如果没有设置窗口无法关闭。
		// 在Swing里面提供简化的方法
		super.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

		// 初始化登陆界面，添加登陆的时候需要的组件
		init();
	}

	private void init() {

		// 设置窗口的布局管理器，为三行一列
		super.setLayout(new GridLayout(5, 1, 10, 10));

		JPanel emptyPanel = new JPanel();
		// emptyPanel.setBackground(Color.BLACK);
		super.add(emptyPanel);

		// 分别添加三个JPanel，用于输入IP、昵称、登陆按钮
		JPanel ipPanel = new JPanel();
		// ipPanel.setBackground(Color.RED);

		JLabel ipLabel = new JLabel("服务器IP");
		ipPanel.add(ipLabel);

		// 输入IP地址的文本框
		JTextField ipField = new JTextField();
		ipField.setColumns(15);
		ipPanel.add(ipField);

		super.add(ipPanel);
		// /////////////////////////////////////////////////////

		JPanel nickPanel = new JPanel();
		// nickPanel.setBackground(Color.YELLOW);

		JLabel nickLabel = new JLabel("昵   称");
		nickPanel.add(nickLabel);

		// 输入IP地址的文本框
		JTextField nickField = new JTextField();
		nickField.setColumns(15);
		nickPanel.add(nickField);
		super.add(nickPanel);

		// /////////////////////////////////////////////////////////

		JPanel buttonPanel = new JPanel();
		// buttonPanel.setBackground(Color.GREEN);

		JButton loginButton = new JButton("登陆");
		// 点击登陆按钮的时候，需要获取ip和昵称，传递给client对象进行登陆操作
		loginButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				String ip = ipField.getText();
				String nick = nickField.getText();
				// 调用客户端的登陆方法
				client.login(ip, nick);
			}
		});
		buttonPanel.add(loginButton);

		JButton closeButton = new JButton("退出");
		buttonPanel.add(closeButton);
		// 关闭的事件需要写
		closeButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				// 把窗口销毁
				LoginFrame.this.dispose();
			}
		});

		super.add(buttonPanel);
		// ////////////////////////////////////////////////////////

		emptyPanel = new JPanel();
		// emptyPanel.setBackground(Color.BLACK);
		super.add(emptyPanel);
	}

}
