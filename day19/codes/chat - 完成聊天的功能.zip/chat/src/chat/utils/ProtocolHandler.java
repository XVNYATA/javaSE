package chat.utils;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.util.Date;

import chat.vo.Message;

/**
 * 专门负责协议的处理，比如收信息、发信息，以及消息对象的编码、解码过程！
 * 
 * @author lwq
 *
 */
public class ProtocolHandler implements AutoCloseable {

	private Socket socket;
	private InputStream is;
	private OutputStream os;

	private DataInputStream in;
	private DataOutputStream out;

	/**
	 * 接收、发送信息，都是通过Socket进行的！
	 * 
	 * @param socket
	 * @throws IOException
	 */
	public ProtocolHandler(Socket socket) throws IOException {
		this.socket = socket;
		// 基于Socket创建输入流和输出流
		is = socket.getInputStream();
		os = socket.getOutputStream();

		// 这些流并不方便使用，因为Message对象是结构复杂的，而且内容的长度是不定的。
		// 为了能够简化消息的收发，这里使用DataInputStream和DataOutputStream来封装基本的输入流和输出流。
		in = new DataInputStream(is);
		out = new DataOutputStream(os);
	}

	/**
	 * 从Scoket的输入流接收一个消息，并且解码转换为Message对象
	 * 
	 * @return
	 * @throws IOException
	 */
	public Message receive() throws IOException {
		// System.out.println("流里面的剩余数据：" + in.available());
		// 直接会自动读取四个字节，转换为int
		int type = in.readInt();

		// 先读取长度
		int senderLength = in.readInt();
		// 利用长度创建定长的数组
		byte[] senderData = new byte[senderLength];
		// 从输入流里面把数组填满
		in.readFully(senderData);
		// 把byte数组，转换为String
		String sender = new String(senderData, "UTF-8");

		int textContentLength = in.readInt();
		byte[] textContentData = new byte[textContentLength];
		in.readFully(textContentData);
		String textContent = new String(textContentData, "UTF-8");

		long time = in.readLong();
		Date sendTime = new Date(time);

		Message msg = new Message();
		msg.setSender(sender);
		msg.setSendTime(sendTime);
		msg.setTextContent(textContent);
		msg.setType(type);

		return msg;
	}

	/**
	 * 把信息编码，然后通过Socket的输出流发送出去
	 * 
	 * @param msg
	 * @throws IOException
	 */
	public void send(Message msg) throws IOException {
		// 写出消息类型
		out.writeInt(msg.getType());

		String sender = msg.getSender();
		byte[] senderData = sender.getBytes("UTF-8");
		// 写出sender这个String的内容的长度
		out.writeInt(senderData.length);
		out.write(senderData);

		String textContent = msg.getTextContent();
		byte[] textContentData = textContent.getBytes("UTF-8");
		out.writeInt(textContentData.length);
		out.write(textContentData);

		// 时间直接发送long
		out.writeLong(msg.getSendTime().getTime());
	}

	@Override
	public void close() {
		try {
			out.close();
		} catch (IOException ex) {
			ex.printStackTrace();
		}
		try {
			in.close();
		} catch (IOException ex) {
			ex.printStackTrace();
		}
		try {
			os.close();
		} catch (IOException ex) {
			ex.printStackTrace();
		}
		try {
			is.close();
		} catch (IOException ex) {
			ex.printStackTrace();
		}
		try {
			socket.close();
		} catch (IOException ex) {
			ex.printStackTrace();
		}
	}
}
