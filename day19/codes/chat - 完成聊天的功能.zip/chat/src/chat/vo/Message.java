package chat.vo;

import java.util.Date;

public class Message {
	/**
	 * 11 登陆消息
	 */
	public static final int CLIENT_TYPE_LOGIN = 11;
	/**
	 * 12 客户端发送的聊天消息
	 */
	public static final int CLIENT_TYPE_CHAT = 12;
	/**
	 * 13 客户端发送的用户离开消息
	 */
	public static final int CLIENT_TYPE_LOGOUT = 13;

	/** 21 登陆成功消息 */
	public static final int SERVER_TYPE_LOGIN_SUCCEED = 21;
	/** 22 登陆失败消息 */
	public static final int SERVER_TYPE_LOGIN_FAILED = 22;
	/** 23 登陆欢迎消息 */
	public static final int SERVER_TYPE_WELCOME = 23;
	/** 24 用户列表更新消息 */
	public static final int SERVER_TYPE_USER_LIST = 24;
	/** 25 服务器广播的聊天消息 */
	public static final int SERVER_TYPE_CHAT = 25;
	/** 26 服务端广播的用户离线消息 */
	public static final int SERVER_TYPE_USER_OFF_LINE = 26;

	/**
	 * 消息类型
	 */
	private int type;

	/**
	 * 消息的发送者，比如张三发送的、系统发送的
	 */
	private String sender;

	/**
	 * 发送时间，统一以服务器时间为准
	 */
	private Date sendTime;

	/**
	 * 消息的文本内容，使用UTF-8的方式进行解码的！
	 */
	private String textContent;

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

	public String getSender() {
		return sender;
	}

	public void setSender(String sender) {
		this.sender = sender;
	}

	public Date getSendTime() {
		return sendTime;
	}

	public void setSendTime(Date sendTime) {
		this.sendTime = sendTime;
	}

	public String getTextContent() {
		return textContent;
	}

	public void setTextContent(String textContent) {
		this.textContent = textContent;
	}

	@Override
	public String toString() {
		return "Message [type=" + type + ", sender=" + sender + ", sendTime="
				+ sendTime + ", textContent=" + textContent + "]";
	}
}
