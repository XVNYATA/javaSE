package chat.server;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Date;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import chat.utils.ProtocolHandler;
import chat.vo.Message;

public class ChatServer {

	/**
	 * 如果在多线程的环境使用HashMap，并且作为成员变量存在的时候，尽量使用ConcurrentHashMap。<br>
	 * 否则会线程不安全的隐患。ConcurrentHashMap是基于乐观锁的线程安全的HashMap实现。
	 */
	private Map<String, ProtocolHandler> userMap = new ConcurrentHashMap<>();

	/**
	 * 创建一个大小为1000的线程池
	 * 
	 */
	private ExecutorService threadPool = Executors.newFixedThreadPool(1000);

	public static void main(String[] args) {
		ChatServer cs = new ChatServer();
		cs.start();
	}

	private void start() {
		try (ServerSocket serverSocket = new ServerSocket(8000)) {

			// 接受客户端的连接
			while (true) {
				Socket socket = serverSocket.accept();

				Runnable task = () -> {
					// 每接收一个，那么就使用一个线程处理
					// 如果不使用线程池，将可能有无数个Socket连接上来，把服务器弄死！
					// 因此建议使用线程池来限制客户端的数量
					try {
						processSocket(socket);
					} catch (Exception e) {
						// TODO 出现异常，意味着客户端已经离线！
						e.printStackTrace();
					}
				};
				threadPool.submit(task);
			}

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private void processSocket(Socket socket) throws IOException {
		// 有Socket以后，就可以创建ProtocolHandler
		try (ProtocolHandler handler = new ProtocolHandler(socket);) {

			// 不断接收信息
			while (true) {
				Message msg = handler.receive();
				// System.out.println("服务器收到的信息:\n    " + msg);

				// 1.判断消息类型
				if (msg.getType() == Message.CLIENT_TYPE_LOGIN) {
					// 登陆消息，执行登陆的过程
					login(msg, handler);
				} else if (msg.getType() == Message.CLIENT_TYPE_CHAT) {
					// 广播之前，应该把时间改为服务器的当前时间，统一所有客户端显示的时间
					msg.setSendTime(new Date());
					msg.setType(Message.SERVER_TYPE_CHAT);
					// 广播
					this.sendMessageToAllUsers(msg);
				}
			}
		}
	}

	private void login(Message msg, ProtocolHandler handler) throws IOException {
		// 1.判断昵称，是否已经存在
		String nick = msg.getSender();
		// 2.建立一个Map，key是昵称，value是ProtocolHandler，只要检查到key在map里面存在，表示用户重复！
		if (userMap.containsKey(nick)) {
			// 用户存在
			Message response = new Message();
			response.setSender("系统");
			response.setSendTime(new Date());
			// 登陆失败
			response.setType(Message.SERVER_TYPE_LOGIN_FAILED);
			response.setTextContent("昵称 " + nick + " 已经被占用");

			// 通过handler发响应的信息，返回给客户端
			handler.send(response);
		} else {
			// 用户不存在
			// 把新的用户添加到userMap里面
			userMap.put(nick, handler);

			Message response = new Message();
			response.setSender("系统");
			response.setSendTime(new Date());
			// 登陆失败
			response.setType(Message.SERVER_TYPE_LOGIN_SUCCEED);
			response.setTextContent("登陆成功");

			// 通过handler发响应的信息，返回给客户端
			handler.send(response);

			// 广播欢迎消息
			sendWelcome(nick);

			// 广播用户列表
			sendUserListUpdate();
		}
	}

	private void sendWelcome(String nick) {
		Message msg = new Message();
		msg.setSender("系统");
		msg.setSendTime(new Date());
		msg.setTextContent("欢迎 " + nick + " 登陆聊天系统");
		msg.setType(Message.SERVER_TYPE_WELCOME);

		sendMessageToAllUsers(msg);
	}

	private void sendUserListUpdate() {
		// 把所有用户的昵称，拼成一个字符串，使用换行进行分隔多个用户！
		StringBuilder builder = new StringBuilder();
		userMap.forEach((nick, v) -> {
			builder.append(nick);
			builder.append("\n");
		});

		// 删除最后一个换行
		builder.deleteCharAt(builder.length() - 1);

		String textContent = builder.toString();
		Message msg = new Message();
		msg.setSender("系统");
		msg.setSendTime(new Date());
		msg.setTextContent(textContent);
		msg.setType(Message.SERVER_TYPE_USER_LIST);

		sendMessageToAllUsers(msg);
	}

	private void sendMessageToAllUsers(Message msg) {
		// 找到所有的ProtocolHandler进行发送！
		userMap.forEach((k, v) -> {
			try {
				v.send(msg);
			} catch (Exception e) {
				// TODO 出现异常，意味着客户端已经离线！
				e.printStackTrace();
			}
		});
	}
}
