package chat;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTextArea;

public class ChatFrame extends MyFrame {

	private ChatClient client;

	public ChatFrame(ChatClient chatClient) {
		super("群聊界面");
		this.client = chatClient;

		// 设置窗口的大小和位置
		setWindowSizeAndLocation(800, 600);

		// 设置处理关闭事件。如果没有设置窗口无法关闭。
		// 在Swing里面提供简化的方法
		super.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

		// 初始化聊天的界面，添加各种组件
		init();
	}

	private void init() {

		// 添加一个左右分栏的容器
		JSplitPane topPane = new JSplitPane();
		// 设置分隔符的位置，从左边开始算
		topPane.setDividerLocation(600);
		topPane.setDividerSize(0);
		super.add(topPane);
		// /////////////////////////////////////////////////////////////////////////////////////////////

		// 添加在左边的上下的JSplitPane
		JSplitPane left = new JSplitPane(JSplitPane.VERTICAL_SPLIT);
		left.setDividerLocation(450);
		topPane.add(left, JSplitPane.LEFT);
		// /////////////////////////////////////////////////////////////////////////////////////////////

		// 在左上角添加一个可以滚动的文本区域，作为聊天记录。
		JTextArea chatRecored = new JTextArea("聊天记录");
		JScrollPane chatRecoredPane = new JScrollPane(chatRecored);
		left.add(chatRecoredPane, JSplitPane.TOP);

		// /////////////////////////////////////////////////////////////////////////////////////////////

		// 添加左下的输入框和按钮区域
		JPanel inputPanel = new JPanel();
		inputPanel.setLayout(new BorderLayout());

		left.add(inputPanel, JSplitPane.BOTTOM);

		// 左下的中间位置，是一个输入框，也可以滚动
		JTextArea inputMessage = new JTextArea("输入信息");
		JScrollPane inputMessagePane = new JScrollPane(inputMessage);
		inputPanel.add(inputMessagePane, BorderLayout.CENTER);

		// 左下的南边添加一个JPanel作为按钮容器，并且使用流布局，右对齐。
		JPanel buttonPanel = new JPanel();
		FlowLayout layout = new FlowLayout(FlowLayout.RIGHT);
		buttonPanel.setLayout(layout);
		// 添加两个按钮
		JButton sendButton = new JButton("发送");
		JButton closeButton = new JButton("关闭");
		buttonPanel.add(sendButton);
		sendButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				// 获取输入框的信息
				String msg = inputMessage.getText();
				boolean succeed = client.sendMessage(msg);
				if (succeed) {
					// 发送成功
					inputMessage.setText("");
				} else {
					// 直接弹出错误信息对话框
					JOptionPane.showMessageDialog(ChatFrame.this,
							"信息发送失败，可能是网络出现了问题", "错误提示",
							JOptionPane.ERROR_MESSAGE);
				}
			}
		});

		buttonPanel.add(closeButton);
		closeButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				dispose();
			}
		});
		inputPanel.add(buttonPanel, BorderLayout.SOUTH);

		// /////////////////////////////////////////////////////////////////////////////////////////////

		// 添加右边的组件
		JSplitPane right = new JSplitPane(JSplitPane.VERTICAL_SPLIT);
		right.setDividerLocation(150);
		topPane.add(right, JSplitPane.RIGHT);

		// 往right里面添加两个JPanel
		JPanel infoPanel = new JPanel();
		infoPanel.setLayout(new BorderLayout());
		right.add(infoPanel, JSplitPane.TOP);
		JPanel userListPanel = new JPanel();
		userListPanel.setLayout(new BorderLayout());
		right.add(userListPanel, JSplitPane.BOTTOM);

		// 添加JList显示用户列表
		DefaultListModel<String> model = new DefaultListModel<>();
		model.addElement("张三");
		model.addElement("张y");
		model.addElement("张q");
		model.addElement("张,");
		model.addElement("张o");
		model.addElement("张l");
		model.addElement("张x");
		model.addElement("张g");
		model.addElement("张e");
		model.addElement("张f");
		model.addElement("张d");
		model.addElement("张c");
		model.addElement("张b");
		model.addElement("张a");
		model.addElement("张9");
		model.addElement("张0");
		model.addElement("张8");
		model.addElement("张7");
		model.addElement("张6");
		model.addElement("张5");
		model.addElement("张4");
		model.addElement("张3");
		model.addElement("李四");
		model.addElement("李四");
		model.addElement("李四");
		model.addElement("李四");
		model.addElement("李四");
		model.addElement("李四");

		JList<String> userList = new JList<>(model);
		JScrollPane userListScrollPane = new JScrollPane(userList);
		userListPanel.add(userListScrollPane);
	}

}
