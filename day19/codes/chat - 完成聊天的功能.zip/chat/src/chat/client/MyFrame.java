package chat.client;

import java.awt.Dimension;

import javax.swing.JFrame;

public class MyFrame extends JFrame {

	public MyFrame(String title) {
		super(title);
	}

	protected void setWindowSizeAndLocation(int width, int height) {
		// int width = 300;
		// int height = 200;

		// 设置窗口大小
		this.setSize(width, height);

		// 设置窗口居中
		// 1.要获取当前的屏幕可用宽度和高度
		Dimension screenSize = this.getToolkit().getScreenSize();
		int screenWidth = (int) screenSize.getWidth();
		int screenHeight = (int) screenSize.getHeight();
		// 2.把获取到的宽度和高度除以二，并且减去窗口的宽度和高度的一半，得到x和y
		int x = screenWidth / 2 - width / 2;
		int y = screenHeight / 2 - height / 2;
		// 3.设置窗口的位置
		this.setLocation(x, y);
	}
}
