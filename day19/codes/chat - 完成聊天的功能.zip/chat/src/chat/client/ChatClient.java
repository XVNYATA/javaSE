package chat.client;

import java.io.IOException;
import java.net.Socket;
import java.util.Date;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import chat.utils.ProtocolHandler;
import chat.vo.Message;

/**
 * 聊天客户端入口
 * 
 * @author lwq
 *
 */
public class ChatClient {

	// 用于保存当前正在显示的界面
	private JFrame loginFrame;
	private JFrame currentWindow;
	private ProtocolHandler handler;
	private ChatFrame chatFrame;
	private String nick;

	public ChatClient() {
		chatFrame = new ChatFrame(this);
	}

	public static void main(String[] args) {
		ChatClient client = new ChatClient();

		// 打开程序的时候，首先显示登陆界面
		LoginFrame loginFrame = new LoginFrame(client);
		loginFrame.setVisible(true);

		// 表示当前正在显示登陆窗口
		client.loginFrame = loginFrame;
		client.currentWindow = loginFrame;
	}

	public void login(String ip, String nick) {

		// 直接创建一个Socket对象，连接到ip对应的8000端口
		try {
			// 应该在退出程序的时候，才能关闭
			// 而且在关闭Socket之前，必须先把流关闭了！
			Socket socket = new Socket(ip, 8000);

			handler = new ProtocolHandler(socket);
			// 在发送信息之前，需要先启动一个线程，不断接收来自服务器的信息。
			Thread receiveThread = new Thread(() -> {
				prcessReceive();
			});
			receiveThread.start();

			this.nick = nick;
			// 发送一个登陆消息给服务器
			Message msg = new Message();
			msg.setSender(nick);
			msg.setSendTime(new Date());
			msg.setTextContent(nick);
			msg.setType(Message.CLIENT_TYPE_LOGIN);

			handler.send(msg);

		} catch (IOException e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(this.currentWindow,
					"网络异常：" + e.getLocalizedMessage(), "错误",
					JOptionPane.ERROR_MESSAGE);
		}
	}

	private void prcessReceive() {
		try {
			while (true) {
				Message msg = handler.receive();
				// System.out.println(msg);
				switch (msg.getType()) {
				case Message.SERVER_TYPE_LOGIN_SUCCEED:
					// 登陆成功消息
					// 销毁登陆窗口，显示聊天窗口
					// 为了能够更快显示聊天的窗口，所以建议在ChatClient的构造器里面，先创建好聊天窗口，但是不显示。
					this.loginFrame.dispose();
					this.chatFrame.setVisible(true);
					// 弹出对话框的时候始终要用当前窗口作为owner
					this.currentWindow = this.chatFrame;
					break;

				case Message.SERVER_TYPE_LOGIN_FAILED:
					// 登陆失败消息
					JOptionPane.showMessageDialog(this.currentWindow, "登陆失败: "
							+ msg.getTextContent(), "错误",
							JOptionPane.ERROR_MESSAGE);
					break;

				case Message.SERVER_TYPE_USER_LIST:
					// 用户列表更新消息
					String textContent = msg.getTextContent();
					// 用户是使用\n分隔的，此时利用分隔符劈开就能够得到多个用户
					String[] users = textContent.split("\n");
					this.chatFrame.updateUserList(users);
					break;

				case Message.SERVER_TYPE_WELCOME:
					// 欢迎消息
				case Message.SERVER_TYPE_CHAT:
					this.chatFrame.appendChatRecord(msg);
					break;
				default:
					break;
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			handler.close();
		}
	}

	public boolean sendMessage(String msg) {
		Message message = new Message();
		message.setSender(nick);
		message.setSendTime(new Date());
		message.setTextContent(msg);
		message.setType(Message.CLIENT_TYPE_CHAT);

		try {
			handler.send(message);
			return true;
		} catch (IOException e) {
			e.printStackTrace();
		}
		return false;
	}
}
