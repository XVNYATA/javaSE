package chat;

import javax.swing.JFrame;

/**
 * 聊天客户端入口
 * 
 * @author lwq
 *
 */
public class ChatClient {

	// 用于保存当前正在显示的界面
	private JFrame currentWindow;

	public static void main(String[] args) {
		ChatClient client = new ChatClient();

		// 打开程序的时候，首先显示登陆界面
		LoginFrame loginFrame = new LoginFrame(client);
		loginFrame.setVisible(true);

		// 表示当前正在显示登陆窗口
		client.currentWindow = loginFrame;
	}

	public void login(String ip, String nick) {

		System.out.println("登陆到 : " + ip + "，昵称为: " + nick);

		// 假设现在是登陆成功，就应该要把登陆界面销毁，显示聊天界面
		boolean succeed = true;// 登陆成功为true
		if (succeed) {
			this.currentWindow.dispose();

			// 创建聊天界面
			ChatFrame chatFrame = new ChatFrame(this);
			this.currentWindow = chatFrame;
			chatFrame.setVisible(true);
		}
	}

	public boolean sendMessage(String msg) {
		return false;
	}
}
