package chat.utils;

import java.net.Socket;

import chat.vo.Message;

/**
 * 专门负责协议的处理，比如收信息、发信息，以及消息对象的编码、解码过程！
 * 
 * @author lwq
 *
 */
public class ProtocolHandler {

	private Socket socket;

	/**
	 * 接收、发送信息，都是通过Socket进行的！
	 * 
	 * @param socket
	 */
	public ProtocolHandler(Socket socket) {
		this.socket = socket;
	}

	/**
	 * 从Scoket的输入流接收一个消息，并且解码转换为Message对象
	 * 
	 * @return
	 */
	public Message receive() {
		return null;
	}

	/**
	 * 把信息编码，然后通过Socket的输出流发送出去
	 * 
	 * @param msg
	 */
	public void send(Message msg) {

	}
}
