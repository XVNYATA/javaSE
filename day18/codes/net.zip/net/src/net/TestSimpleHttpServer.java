package net;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URI;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import javax.activation.MimetypesFileTypeMap;

/**
 * 简单的、单线程的HTTP服务器
 * 
 * @author lwq
 *
 */
public class TestSimpleHttpServer {

	private static MimetypesFileTypeMap fileTypeMap = new MimetypesFileTypeMap();

	public static void main(String[] args) {
		// 手动增加映射
		fileTypeMap.addMimeTypes("text/plain txt text TXT");
		fileTypeMap.addMimeTypes("image/jpeg jpg jpeg");
		fileTypeMap.addMimeTypes("image/gif gif");
		fileTypeMap.addMimeTypes("image/png png");
		fileTypeMap.addMimeTypes("image/x-icon icon");
		fileTypeMap.addMimeTypes("text/css css CSS");
		fileTypeMap.addMimeTypes("text/javascript js JS");
		fileTypeMap.addMimeTypes("text/html html htm");

		// 1.监听端口
		try (ServerSocket serverSocket = new ServerSocket(8000);) {
			// 2.不断accept
			while (true) {
				Socket socket = serverSocket.accept();
				// 3.处理Socket
				try {
					processSocket(socket);
				} catch (Exception ex) {
					ex.printStackTrace();
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private static void processSocket(Socket socket) throws IOException {

		try (InputStream in = socket.getInputStream();
				OutputStream out = socket.getOutputStream();) {
			// 2.在处理Socket的时候，先把请求里面的URI找出来
			String uri = getURI(in);

			// 3.根据找出的URI，创建一个File对象，File对象作为硬盘上某个文件夹的子文件来创建。
			File file = new File("/tmp/http", uri);
			System.out.println("文件的绝对路径：" + file.getAbsolutePath());

			// 判断文件是否存在，如果不存在发送404错误
			if (file.exists()) {
				// 4.创建一个文件输入流，把文件输入流里面的数据复制到Socket的输出流。
				sendFile(out, file);
			} else {
				send404(out, file);
			}
		}
	}

	private static void send404(OutputStream out, File file) throws IOException {
		// 首先要准备好返回给浏览器的信息
		String content = "服务器里面没有找到 " + file.getAbsolutePath() + " 文件";
		// 表示把contnet以GBK的方式，转换为byte数组
		byte[] contentData = content.getBytes("GBK");

		// 其次要准备响应头
		StringBuilder headerBuilder = new StringBuilder();
		// 状态行
		headerBuilder.append("HTTP/1.1 404 File Not Found!");
		headerBuilder.append("\r\n");

		// 内容类型
		headerBuilder.append("Content-Type: text/html;charset=GBK");
		headerBuilder.append("\r\n");

		// 内容长度
		headerBuilder.append("Content-Length: " + contentData.length);
		headerBuilder.append("\r\n");

		// 增加一个空行，表示响应头结束
		headerBuilder.append("\r\n");

		// 把响应头转换为字节数组
		// 响应头里面是不允许有中文的，所以直接使用getBytes方法，不需要传参接口。
		byte[] headerData = headerBuilder.toString().getBytes();

		// 最后把两个数组分别写出到流
		out.write(headerData);
		out.write(contentData);
	}

	private static void sendFile(OutputStream out, File file)
			throws IOException {
		// 1.拼接响应头信息
		StringBuilder headerBuilder = new StringBuilder();
		headerBuilder.append("HTTP/1.1 200 OK").append("\r\n");

		// 根据文件获取内容类型
		String contentType = fileTypeMap.getContentType(file);
		headerBuilder.append("Content-Type: ").append(contentType)
				.append("\r\n");
		headerBuilder.append("Content-Length: ").append(file.length())
				.append("\r\n");
		headerBuilder.append("\r\n");

		// 写出头信息
		byte[] headerData = headerBuilder.toString().getBytes();
		out.write(headerData);

		// 2.把文件的内容在头信息的后面输出
		URI u = file.toURI();
		Path source = Paths.get(u);
		Files.copy(source, out);
	}

	/**
	 * 从请求头信息中截取uri出来
	 * 
	 * @param in
	 * @return
	 * @throws IOException
	 */
	private static String getURI(InputStream in) throws IOException {
		byte[] buffer = new byte[1024];
		int c = in.read(buffer);

		// 需要有一个StringBuilder把整个请求信息全部装起来
		StringBuilder builder = new StringBuilder();

		while (c != -1) {
			String data = new String(buffer, 0, c);
			builder.append(data);

			if (in.available() > 0) {
				c = in.read(buffer);
			} else {
				break;
			}
		}

		// 循环完以后，builder里面的信息，就是完整的请求消息，浏览器发送的所有数据都在builder里面。
		// URI在第一行
		// GET /a/index.html HTTP/1.1
		String uri = builder.substring(0, builder.indexOf("\r\n"));
		// 从第一个空格之后，开始截取内容
		// /a/index.html HTTP/1.1
		uri = uri.substring(uri.indexOf(" ") + 1);

		// /a/index.html
		uri = uri.substring(0, uri.indexOf(" "));

		System.out.println("截取得到的URI:|" + uri + "|");
		return uri;
	}
}
