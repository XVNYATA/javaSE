package net;

import java.io.IOException;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;

/**
 * 测试返回信息给浏览器
 * 
 * @author lwq
 *
 */
public class TestHttpResponse {

	public static void main(String[] args) throws IOException {

		// 1.绑定到端口
		try (ServerSocket serverSocket = new ServerSocket(8000)) {
			// 2.不断接受请求
			while (true) {
				Socket socket = serverSocket.accept();

				// 处理Socket连接
				processSocket(socket);
			}
		}
	}

	private static void processSocket(Socket socket) throws IOException {
		// 返回信息给浏览器
		try (OutputStream out = socket.getOutputStream();) {
			// 首先要准备好返回给浏览器的信息
			String content = "这个是服务器返回的文字内容";
			// 表示把contnet以GBK的方式，转换为byte数组
			byte[] contentData = content.getBytes("GBK");

			// 其次要准备响应头
			StringBuilder headerBuilder = new StringBuilder();
			// 状态行
			headerBuilder.append("HTTP/1.1 200 OK");
			headerBuilder.append("\r\n");

			// 内容类型
			headerBuilder.append("Content-Type: text/html;charset=GBK");
			headerBuilder.append("\r\n");

			// 内容长度
			headerBuilder.append("Content-Length: " + contentData.length);
			headerBuilder.append("\r\n");

			// 增加一个空行，表示响应头结束
			headerBuilder.append("\r\n");

			// 把响应头转换为字节数组
			// 响应头里面是不允许有中文的，所以直接使用getBytes方法，不需要传参接口。
			byte[] headerData = headerBuilder.toString().getBytes();
			
			//最后把两个数组分别写出到流
			out.write(headerData);
			out.write(contentData);
		}
	}
}
