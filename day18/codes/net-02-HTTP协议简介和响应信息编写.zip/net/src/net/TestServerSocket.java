package net;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class TestServerSocket {

	public static void main(String[] args) throws IOException {
		System.out.println("服务器启动");
		// 1.服务器需要监听/绑定一个端口。
		// 这里使用 8000 端口。

		// 创建一个服务器端的Socket，绑定到8000端口
		try (ServerSocket serverSocket = new ServerSocket(8000);) {

			// 2.服务器不断接收浏览器的连接
			while (true) {
				System.out
						.println("服务器就绪，可以在浏览器输入 http://127.0.0.1:8000 访问服务器");

				// 接受浏览器（客户端）的连接，连接建立以后，会得到一个Socket对象。
				// Socket表示两台电脑连接的一个通道。
				Socket socket = serverSocket.accept();

				System.out.println("浏览器连接成功，浏览器使用的端口是："
						+ socket.getRemoteSocketAddress());

				// 3.接收到连接以后，需要创建输入流，获取数据
				// 通过Socket通道获取的输入流，可以获取对方发送过来的信息
				InputStream in = socket.getInputStream();

				// 把客户端发送过来的信息，全部接收
				byte[] buffer = new byte[1024];
				int c = in.read(buffer);
				while (c != -1) {
					// 输出获取到的数据到控制台
					String s = new String(buffer, 0, c);
					System.out.print(s);

					// 必须判断输入流里面还有可以用数据，才能继续读取
					// 否则会导致无限等待
					if (in.available() > 0) {
						c = in.read(buffer);
					} else {
						// 如果输入流已经没有数据了，需要离开循环
						break;
					}
				}
				System.out.println();
				System.out.println("输出接收完成");

				// 4.数据处理完成以后，使用输出流把信息返回给浏览器

				// 把数据发送给对方的输出流
				OutputStream out = socket.getOutputStream();
			}
		}
	}
}
